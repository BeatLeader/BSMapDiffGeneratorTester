﻿// See https://aka.ms/new-console-template for more information
using beatleader_parser;
using BSMapDiffGenerator;
using Newtonsoft.Json;
using Parser.Map;
using Parser.Map.Difficulty.V3.Base;

Console.WriteLine("Hello, World!");
Console.WriteLine("input old map location");
string location = Console.ReadLine();

Console.WriteLine("input new map location");
string newlocation = Console.ReadLine();

Parse parser = new();
BeatmapV3 oldMap = parser.TryLoadPath(location);
BeatmapV3 newMap = parser.TryLoadPath(newlocation);


var diff = MapDiffGenerator.GenerateDifficultyDiff(newMap.Difficulties[0].Data, oldMap.Difficulties[0].Data);

Console.WriteLine(JsonConvert.SerializeObject(diff, Formatting.Indented));

File.WriteAllText("diff.json", JsonConvert.SerializeObject(diff, Formatting.Indented));
File.WriteAllText("newMap.json", JsonConvert.SerializeObject(newMap.Difficulties[0].Data, Formatting.Indented));
File.WriteAllText("oldMap.json", JsonConvert.SerializeObject(oldMap.Difficulties[0].Data, Formatting.Indented));